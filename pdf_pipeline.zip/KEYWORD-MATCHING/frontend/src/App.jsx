import React from "react";
import Analyzer from "./components/Analyzer";

export default function App() {
  return <Analyzer />;
}
