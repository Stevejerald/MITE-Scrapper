import os
import time
import json
import mysql.connector
import subprocess
from playwright.sync_api import sync_playwright
import re
import requests

# ---------------------------------------------------
# DB CONFIG
# ---------------------------------------------------

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "tender_automation_with_ai"
}

PDF_DIR = "PDF"
JSON_DIR = "OUTPUT"
os.makedirs(PDF_DIR, exist_ok=True)
os.makedirs(JSON_DIR, exist_ok=True)


# ---------------------------------------------------
# Filename sanitizer
# ---------------------------------------------------

def safe_name(text):
    """Convert bid_number into safe filename: remove / \ spaces etc."""
    return re.sub(r'[^A-Za-z0-9_-]', '_', text)


# ---------------------------------------------------
# DB helpers
# ---------------------------------------------------

def db_connect():
    return mysql.connector.connect(**DB_CONFIG)


def fetch_pending_tenders(limit=50):
    conn = db_connect()
    cur = conn.cursor(dictionary=True)

    cur.execute("""
        SELECT bid_number, detail_url
        FROM gem_tenders
        WHERE bid_number NOT IN (SELECT bid_number FROM gem_tender_docs)
        LIMIT %s
    """, (limit,))

    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows


def save_doc_record(bid_number, detail_url, pdf_url, pdf_path, json_path):
    conn = db_connect()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO gem_tender_docs (bid_number, detail_url, pdf_url, pdf_path, json_path)
        VALUES (%s,%s,%s,%s,%s)
        ON DUPLICATE KEY UPDATE
            pdf_url = VALUES(pdf_url),
            pdf_path = VALUES(pdf_path),
            json_path = VALUES(json_path)
    """, (bid_number, detail_url, pdf_url, pdf_path, json_path))

    conn.commit()
    cur.close()
    conn.close()


# ---------------------------------------------------
# Extract PDF URL from tender detail page
# ---------------------------------------------------

def extract_pdf_url(detail_url):
    # Case 1: URL already IS a PDF link
    if detail_url.lower().endswith(".pdf"):
        return detail_url

    # Case 2: Gem "showbidDocument" -> ALWAYS direct PDF download
    if "showbidDocument" in detail_url:
        return detail_url

    # Try opening it normally in browser
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()

        try:
            page.goto(detail_url, timeout=0, wait_until="domcontentloaded")
        except Exception:
            # Playwright error -> means this URL triggered direct PDF download
            browser.close()
            return detail_url

        links = page.query_selector_all("a")
        for link in links:
            href = link.get_attribute("href")
            if href and ".pdf" in href.lower():
                if href.startswith("/"):
                    href = "https://bidplus.gem.gov.in" + href
                browser.close()
                return href

        browser.close()
        return None


# ---------------------------------------------------
# Download PDF to ./PDF/
# ---------------------------------------------------

def download_pdf(pdf_url, bid_number):
    safe_bid = safe_name(bid_number)
    fname = f"{safe_bid}.pdf"
    path = os.path.join(PDF_DIR, fname)

    r = requests.get(pdf_url, timeout=30)
    if r.status_code == 200:
        with open(path, "wb") as f:
            f.write(r.content)
        return path

    return None


# ---------------------------------------------------
# Call your existing deep extractor (url_pdf_extraction.py)
# ---------------------------------------------------

def extract_json_from_pdf(pdf_path):
    safe_bid = safe_name(os.path.basename(pdf_path).replace(".pdf", ""))
    json_path = os.path.join(JSON_DIR, f"{safe_bid}.json")

    # Correct extraction-only command
    cmd = [
        "python",
        "url_pdf_extraction.py",
        "--skip-download",         # do not redownload PDFs
        "--pdf-folder", PDF_DIR,
        "--out-folder", JSON_DIR,
    ]

    subprocess.run(cmd)

    return json_path if os.path.exists(json_path) else None


# ---------------------------------------------------
# MAIN PIPELINE
# ---------------------------------------------------

def process_tenders():
    tenders = fetch_pending_tenders()
    if not tenders:
        print("No pending tenders.")
        return

    for t in tenders:
        bid = t["bid_number"]
        url = t["detail_url"]

        print(f"\nProcessing {bid}")

        # Get PDF link
        pdf_url = extract_pdf_url(url)
        if not pdf_url:
            print("❌ No PDF found on page.")
            continue

        print("PDF:", pdf_url)

        # Download PDF
        pdf_path = download_pdf(pdf_url, bid)
        if not pdf_path:
            print("❌ Failed to download PDF.")
            continue

        print("PDF saved:", pdf_path)

        # Extract JSON
        json_path = extract_json_from_pdf(pdf_path)
        if not json_path:
            print("❌ JSON not created.")
            continue

        print("JSON saved:", json_path)

        # Save in DB
        save_doc_record(bid, url, pdf_url, pdf_path, json_path)
        print(f"✔ Saved DB record for {bid}")


# ---------------------------------------------------
# ENTRYPOINT
# ---------------------------------------------------

if __name__ == "__main__":
    while True:
        process_tenders()
        print("\nSleeping for 2 minutes...\n")
        time.sleep(120)
